# Artifact: Correction Fault Attacks on Randomized CRYSTALS-Dilithium

This is the artifact for the paper "Correction Fault Attacks on Randomized CRYSTALS-Dilithium" by Elisabeth Krahmer, Peter Pessl, Georg Land, and Tim Güneysu published at TCHES 2024/3.
The artifact consists of three independent parts:
1. the fault attack on the expansion of A,
2. the lattice reduction that enables to recover the full secret key even if not all coefficients are known, and
3. the skipping fault attack.

For convenience, all three parts can be built with running `sudo docker build -t dilfaults .` in this directory, and executed subsequently with `sudo docker run -t dilfaults`.
Alternatively, individual instructions are given below.


# Correction Fault Attack on Expansion of A

## Prerequisites
For the code, we the NTL and GMP libraries to be installed.
Furthermore, the machine must feature avx2 instructions (the code will fail with `illegal instruction` if this is not the case).

## Building
`make -j` builds:
- the adapted avx2 dilithium code
- the gen_faulty_sigX (X=2,3,5) programs that generate simulated faulty signatures
- test_X_fA (X=2,3,5) programs that recover the secret key coefficients in NTT domain (note that this, depending on the number of threads available on your system, might run for multiple hours)

We tested this successfully (and without warnings) with gcc versions 11.4.0 and 13.1.0.

## Running
```
chmod +x run.sh
./run.sh
```
runs for each Dilithium parameter set:
- the fault simulation
- the secret key recovery

# Lattice Reduction to recover s1 from known coefficients in s1hat

## Prerequisites
For the code, we require the NTL, FPLLL and GMP libraries to be installed.

## Building
`make` builds:
- the C dilithium2 code
- the test_latticered program that recovers s1 polynomials from X known coefficients in s1hat at random positions, for X={250, 240, 128}, BKZ block sizes being {5,8,30}, testing 8 polynomials each

We tested this successfully (and without warnings) with gcc version 11.4.0.

## Running
```
chmod +x run.sh
./run.sh
```
runs the lattice reduction tests

# Skipping Fault Correction Attack

## Prerequisites
For the code, we require the NTL and GMP libraries to be installed.

## Building
`make` builds:
- the adapted C dilithium code
- test_X_skip (X=2,3,5) generates programs that recover the secret key using simulated skipping faults, 10 tests each
- test_X_skip_shuff (X=2,3,5) generates programs that recover the secret key using simulated skipping faults that are injected in random coefficients, 2 tests each
- test_X_skip_ineff (X=2,3,5) generates programs that recover the secret key using only ineffective simulated skipping faults, 5 tests each

We tested this successfully (and without warnings) with gcc versions 11.4.0 and 13.1.0.
Please *do not* use `make -j`, which may not work in this directory.

## Running
```
chmod +x run.sh
./run.sh
```
runs for each Dilithium parameter set:
- the secret key recovery for all three attack variants
