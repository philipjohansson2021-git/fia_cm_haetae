#!/bin/sh

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:./dilithium/avx2
export OMP_NESTED=TRUE

echo "Testing coefficient recovery for Dilithium2 with simulated faults (1024 coefficients total)"
./gen_faulty_sig2
./test_2_fA

echo "Testing coefficient recovery for Dilithium3 with simulated faults (1280 coefficients total)"
./gen_faulty_sig3
./test_3_fA

echo "Testing coefficient recovery for Dilithium5 with simulated faults (1792 coefficients total)"
./gen_faulty_sig5
./test_5_fA