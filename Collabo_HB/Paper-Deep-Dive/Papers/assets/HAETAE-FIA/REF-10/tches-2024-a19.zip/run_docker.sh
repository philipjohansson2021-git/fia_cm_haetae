#!/bin/sh

echo "Fault A"
cd /home/dilfaults/fault_A && ./run.sh

echo "Lattice reduction"
cd /home/dilfaults/latticeReduction && ./run.sh

echo "Skipping fault"
cd /home/dilfaults/skippingFault && ./run.sh