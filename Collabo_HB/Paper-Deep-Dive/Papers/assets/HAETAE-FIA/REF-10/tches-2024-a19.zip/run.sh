#!/bin/sh

echo "Fault A"
./fault_A/run.sh

echo "Lattice reduction"
./latticeReduction/run.sh

echo "Skipping fault"
./skippingFault/run.sh