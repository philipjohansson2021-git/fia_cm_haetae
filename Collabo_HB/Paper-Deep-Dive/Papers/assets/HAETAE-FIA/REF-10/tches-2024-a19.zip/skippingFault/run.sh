#!/bin/sh

echo "Testing skipping faults without countermeasures."
echo "Dilithium2"
./test_2_skip
echo "Dilithium3"
./test_3_skip
echo "Dilithium5"
./test_5_skip

echo "Testing ineffective skipping faults without countermeasures."
echo "Dilithium2"
./test_2_skip_ineff
echo "Dilithium3"
./test_3_skip_ineff
echo "Dilithium5"
./test_5_skip_ineff

echo "Testing skipping faults with shuffling countermeasure."
echo "Dilithium2"
./test_2_skip_shuff
echo "Dilithium3"
./test_3_skip_shuff
echo "Dilithium5"
./test_5_skip_shuff
